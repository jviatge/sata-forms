module.exports = {
  content: ["./**/*.php", "./src/**/*.js", "./src/**/*.jsx", "./src/**/*.css"]
}