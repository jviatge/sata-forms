# Sata-forms [Wordpress]

This is a form plugin that contacts an api

## Compatability

- Wordpress 5.7.2
- Elementor 3.2.2

## Development

``pnpm install``

``pnpm run build``

``pnpm run watch``