module.exports = {
  plugins: {
    "postcss-nested": {},
    tailwindcss: {},
    autoprefixer: {}
  }
}
